IUC has taken over
==================

The BED tools wrappers are now located under https://github.com/galaxyproject/tools-iuc/tree/master/tools/bedtools.
Maintenance and development will happen under the IUC umbrella!
