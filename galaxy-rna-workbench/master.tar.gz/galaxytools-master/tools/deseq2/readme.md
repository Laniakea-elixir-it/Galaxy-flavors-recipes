IUC has taken over
==================

The DESeq2 wrappers are now located under https://github.com/galaxyproject/tools-iuc/tree/master/tools/deseq2.
Maintenance and development will happen under the IUC umbrella!
