IUC has taken over
==================

The Gemini wrappers are now located under https://github.com/galaxyproject/tools-iuc/tree/master/tools/gemini.
Maintenance and development will happen under the IUC umbrella!
