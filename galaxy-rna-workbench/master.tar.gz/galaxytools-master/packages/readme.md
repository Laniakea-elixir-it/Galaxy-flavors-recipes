IUC has taken over
==================

Most of my Galaxy tool dependency packages are move to https://github.com/galaxyproject/tools-iuc/tree/master/packages.
Maintenance and development will happen under the IUC umbrella!

See this branch for more details.
https://github.com/galaxyproject/tools-iuc/pull/24

This repository will serve as staging area for packages that are very specific. We might move them
over to IUC at a later time.
